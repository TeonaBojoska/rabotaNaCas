package Zadaca1;

public class HelloWorld {
    public static void main(String[] args){
        String firstString = "Hello";
        String secondString = "World";
        System.out.println(firstString+" "+secondString);
    }
}
