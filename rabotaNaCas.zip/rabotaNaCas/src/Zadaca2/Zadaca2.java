package Zadaca2;

public class Zadaca2 {
    public static void main(String[] args){
        String firstName = "Стефан";
        String lastName = "Стефановски";
        int index = 2222;
        System.out.println("Здраво, јас сум"+" "+firstName+" "+lastName+"."+" "+"Мојот број на индекс е:"+" "+index+".");
    }
}
