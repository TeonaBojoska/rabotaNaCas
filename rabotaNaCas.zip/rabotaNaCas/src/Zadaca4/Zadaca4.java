package Zadaca4;

public class Zadaca4 {
    public static void main(String[] args){
        String unit = "степен";
        String value = "2.5";
        double t=Double.parseDouble(value);
        System.out.println("Температурата изнесува"+" "+(int)(t*10)+" "+unit+"и");
    }
}
