package Zadaca3;

public class Zadaca3 {
    public static void main(String[] args){
        double a = 0.2;
        double b = 0.3;
        String name = "Правоаголник";
        String value1 = "Плоштина";
        System.out.println(name+"от има страни a "+(int)(a*100)+" "+"cm и b "+ (int)(b*100)+"cm.");
        System.out.println(value1+"та изнесува "+ (int)(a*b*1000)+" "+"cm.");
    }
}
